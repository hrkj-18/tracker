'''config.py'''
from pydantic import BaseSettings


class Settings(BaseSettings):
    personal_access_token: str
    organization_url: str
    query_id: str
    business_unit: str
    organization: str
    company: str

    class Config:
        env_file = ".env"


settings = Settings()